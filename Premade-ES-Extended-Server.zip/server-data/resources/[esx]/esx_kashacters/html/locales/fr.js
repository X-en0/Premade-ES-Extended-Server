const translate = new Object();

translate.name = "Nom";
translate.job = "Métier";
translate.bank = "Banque";
translate.money = "Argent";
translate.gender = "Sexe";
translate.dob = "Date de naissance";
translate.new = "Créer un personnage";
translate.delete = "SUPPRIMER";
translate.play = "JOUER";
translate.playNew = "CRÉER UN PERSONNAGE";
translate.modalTitle = "Êtes-vous sûr?";
translate.modalText = "En supprimant votre personnage, vous ne pourrez pas le récupérer. Toutes les informations seront supprimées.";