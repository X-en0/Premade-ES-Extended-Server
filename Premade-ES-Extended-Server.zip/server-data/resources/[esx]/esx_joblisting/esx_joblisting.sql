USE `es_extended`;

ALTER TABLE jobs add whitelisted BOOLEAN NOT NULL DEFAULT FALSE;