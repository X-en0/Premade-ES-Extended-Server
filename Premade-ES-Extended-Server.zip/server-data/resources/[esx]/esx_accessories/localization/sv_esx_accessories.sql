USE `es_extended`;

INSERT INTO `datastore` (name, label, shared) VALUES
	('user_ears', 'Örontillbehör', 0),
	('user_glasses', 'Glasögon', 0),
	('user_helmet', 'Hjälm', 0),
	('user_mask', 'Mask', 0)
;
