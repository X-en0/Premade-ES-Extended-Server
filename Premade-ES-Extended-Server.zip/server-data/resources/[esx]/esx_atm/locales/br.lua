Locales['br'] = {
  ['invalid_amount'] = '~r~Quantidade inválida',
  ['deposit_money']  = 'Você depósitou ~g~$%s~s~',
  ['withdraw_money'] = 'Você retirou ~g~$%s~s~', 
  ['press_e_atm']    = 'pressione ~INPUT_PICKUP~ para depósitos ou retiradas do ~g~ATM~s~.',
  ['atm_blip']       = 'ATM',
}
