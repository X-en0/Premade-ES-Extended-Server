Locales['pl'] = {
  ['new_message'] = '~b~Masz nową wiadomość:~s~ %s',
  ['press_take_call'] = '%s - wciśnij ~INPUT_CONTEXT~ aby odebrać telefon',
  ['taken_call'] = '~y~%s~s~ odebrał telefon',
  ['gps_position'] = 'cel podróży został dodany do GPS\'a',
  ['message_sent'] = 'wiadomość wysłana',
  ['cannot_add_self'] = 'nie możesz dodać samego siebie!',
  ['number_in_contacts'] = 'ten numer jest już na twojej liście kontaktów',
  ['contact_added'] = 'kontakt dodany!',
  ['contact_removed'] = 'kontakt usunięty!',
  ['number_not_assigned'] = 'numer nie jest przypisany!',
  ['invalid_number'] = 'to nie jest prawidłowy numer telefonu!',
}
