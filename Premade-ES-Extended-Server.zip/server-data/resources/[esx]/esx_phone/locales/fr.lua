Locales['fr'] = {
  ['new_message'] = '~b~Nouveau message :~s~ %s',
  ['press_take_call'] = '%s - Appuyez sur ~INPUT_CONTEXT~ pour prendre l\'appel',
  ['taken_call'] = '~y~%s~s~ a pris l\'appel',
  ['gps_position'] = 'position entrée dans le GPS',
  ['message_sent'] = 'message envoyé',
  ['cannot_add_self'] = 'vous ne pouvez pas vous ajouter vous-même',
  ['number_in_contacts'] = 'ce numéro est déja dans votre liste de contacts',
  ['contact_added'] = 'contact ajouté',
  ['contact_removed'] = 'contact supprimé',
  ['number_not_assigned'] = 'ce numéro n\'est pas attribué...',
  ['invalid_number'] = 'that\'s not an valid number!',
}
