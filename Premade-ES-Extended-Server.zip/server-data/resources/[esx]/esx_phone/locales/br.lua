Locales['br'] = {
  ['new_message'] = '~b~Nova mensagem :~s~ %s',
  ['press_take_call'] = '%s - Pressione ~INPUT_CONTEXT~ para aceitar a chamada',
  ['taken_call'] = '~y~%s~s~ recebeu uma chamada',
  ['gps_position'] = 'destino inserido no GPS',
  ['message_sent'] = 'mensagem enviada',
  ['cannot_add_self'] = 'você não pode se adicionar',
  ['number_in_contacts'] = 'este número já está na sua lista de contatos',
  ['contact_added'] = 'contato adicionado',
  ['contact_removed'] = 'the contact has been removed!',
  ['number_not_assigned'] = 'este número não foi atribuído...',
  ['invalid_number'] = 'that\'s not an valid number!',
}
