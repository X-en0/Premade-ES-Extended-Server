Locales['en'] = {
  ['new_message'] = '~b~You have received a message:~s~ %s',
  ['press_take_call'] = '%s - Press ~INPUT_CONTEXT~ to take the call',
  ['taken_call'] = '~y~%s~s~ has taken the call',
  ['gps_position'] = 'the destination has been added to your GPS',
  ['message_sent'] = 'the message has been sent',
  ['cannot_add_self'] = 'you can not add yourself!',
  ['number_in_contacts'] = 'this number is already in your contact list',
  ['contact_added'] = 'the contact has been added!',
  ['contact_removed'] = 'the contact has been removed!',
  ['number_not_assigned'] = 'the number has not been assigned!',
  ['invalid_number'] = 'that\'s not an valid number!',
}
