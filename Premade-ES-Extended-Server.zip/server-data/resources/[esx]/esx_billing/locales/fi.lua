Locales['fi'] = {
  ['invoices'] = 'laskut',
  ['invoices_item'] = '$%s',
  ['received_invoice'] = 'sinä ~r~sait~s~ laskun',
  ['paid_invoice'] = 'sinä ~g~maksoit~s~ laskun suuruudelta ~r~$%s~s~',
  ['no_invoices'] = 'you do not have any bills to pay at this moment',
  ['received_payment'] = 'sinä ~g~sait~s~ maksun suuruudelta ~r~$%s~s~',
  ['player_not_online'] = 'pelaaja ei ole sisäänkirjautuneena',
  ['no_money'] = 'sinulla ei ole tarpeeksi rahaa maksaaksesi tätä laskua.',
  ['target_no_money'] = 'pelaajalla ~r~ei ole~s~ tarpeeksi rahaa maksaakseentätä laskua',
  ['keymap_showbills'] = 'open bills menu',
}
